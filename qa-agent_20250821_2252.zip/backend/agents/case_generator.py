# backend/agents/case_generator.py
import json
import random
import string

# Valores por defecto por tipo
FAKE_DATA = {
    "string": "valor_ejemplo",
    "integer": 123,
    "number": 3.14,
    "boolean": True,
    "email": "test@example.com",
    "date": "2024-01-01"
}

def generate_test_cases(endpoints):
    test_cases = []
    for ep in endpoints:
        valid_case = {
            "endpoint": ep['path'],
            "method": ep['method'],
            "case_type": "valid",
            "payload": _generate_valid_payload(ep),
            "description": f"Prueba válida para {ep['method']} {ep['path']}"
        }
        invalid_case = {
            "endpoint": ep['path'],
            "method": ep['method'],
            "case_type": "invalid",
            "payload": _generate_invalid_payload(ep),
            "description": f"Prueba inválida (campos faltantes) para {ep['method']} {ep['path']}"
        }
        test_cases.append(valid_case)
        test_cases.append(invalid_case)
    return test_cases


def _generate_valid_payload(endpoint):
    payload = {}
    body = endpoint.get('requestBody', {})
    if 'content' in body:
        schema = body['content'].get('application/json', {}).get('schema', {})
        if 'properties' in schema:
            for prop, details in schema['properties'].items():
                prop_type = details.get('type', 'string')
                payload[prop] = FAKE_DATA.get(prop_type, "valor")
    return payload


def _generate_invalid_payload(endpoint):
    payload = _generate_valid_payload(endpoint)
    # Eliminar un campo al azar
    if payload:
        del_key = random.choice(list(payload.keys()))
        del payload[del_key]
    return payload