# backend/agents/spec_parser.py
import os
import yaml
import json
from openapi_spec_validator import validate_spec


def parse_spec(filepath):
    _, ext = os.path.splitext(filepath)
    with open(filepath, 'r', encoding='utf-8') as f:
        if ext == '.yaml' or ext == '.yml':
            spec = yaml.safe_load(f)
        elif ext == '.json':
            spec = json.load(f)
        else:
            raise ValueError("Formato no soportado: solo .json, .yaml, .yml")

    # Validar OpenAPI
    try:
        validate_spec(spec)
        return _parse_openapi(spec)
    except Exception:
        pass

    # Verificar Postman
    if "item" in spec and "info" in spec:
        return _parse_postman(spec)

    raise ValueError("No es un archivo OpenAPI ni Postman válido")


def _parse_openapi(spec):
    paths = spec.get('paths', {})
    endpoints = []

    for path, methods in paths.items():
        for method, details in methods.items():
            if method in ['get', 'post', 'put', 'delete', 'patch']:
                endpoint = {
                    'method': method.upper(),
                    'path': path,
                    'summary': details.get('summary', 'Sin descripción'),
                    'parameters': details.get('parameters', []),
                    'requestBody': details.get('requestBody', {}),
                    'responses': details.get('responses', {})
                }
                endpoints.append(endpoint)

    return {
        "type": "openapi",
        "title": spec.get('info', {}).get('title', 'API'),
        "version": spec.get('info', {}).get('version', '1.0'),
        "endpoints": endpoints
    }


def _parse_postman(collection):
    endpoints = []
    for item in collection.get('item', []):
        if 'request' in item:
            req = item['request']
            endpoint = {
                'method': req['method'],
                'path': req['url'].get('raw', 'desconocido'),
                'summary': item.get('name', 'Sin nombre'),
                'parameters': req.get('url', {}).get('query', []),
                'requestBody': req.get('body', {}),
                'responses': item.get('response', [])
            }
            endpoints.append(endpoint)
        elif 'item' in item:  # Carpetas
            endpoints.extend(_parse_postman({'item': item['item']}))
    return {
        "type": "postman",
        "title": collection.get('info', {}).get('name', 'Colección'),
        "version": "1.0",
        "endpoints": endpoints
    }